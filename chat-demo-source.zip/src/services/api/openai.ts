import type { AssistantMessage, Message, UserMessage } from '../chat/types.js'
import type { ModelProfile } from '../models.js'
import { ApiError } from './client.js'
import { readServerSentEvents } from './sse.js'
import type { MessageStreamEvent } from './types.js'

/**
 * OpenAI Chat Completions 兼容协议的接入层。
 * 把各服务商的流式分片转换成应用内部的 MessageStreamEvent，上层的消息树、状态机都不用改。
 */

export type OpenAIMessage = {
  role: 'system' | 'user' | 'assistant'
  content: string
}

const replyText = (reply: AssistantMessage) =>
  reply.blocks.map((block) => (block.type === 'text' ? block.text : '')).join('')

const fileNote = (message: UserMessage) =>
  message.files.length === 0
    ? ''
    : `\n\n（本消息附带 ${message.files.length} 个文件：${message.files
        .map((file) => file.name)
        .join('、')}。当前模型不支持直接读取附件内容。）`

/** 历史轮次只回传文本：附件、思考、工具块对 OpenAI 兼容模型没有意义 */
export const buildOpenAIMessages = (
  system: string,
  history: Message[],
  question: UserMessage,
  prefix?: AssistantMessage
): OpenAIMessage[] => {
  const messages: OpenAIMessage[] = [{ role: 'system', content: system }]
  for (let index = 0; index + 1 < history.length; index += 1) {
    const user = history[index]
    const reply = history[index + 1]
    if (user.role !== 'user' || reply.role !== 'assistant') {
      continue
    }
    const text = replyText(reply).trim()
    if (!text) {
      continue
    }
    messages.push({ role: 'user', content: user.content + fileNote(user) })
    messages.push({ role: 'assistant', content: text })
    index += 1
  }
  messages.push({ role: 'user', content: question.content + fileNote(question) })
  const prefixText = prefix ? replyText(prefix).trim() : ''
  if (prefixText) {
    messages.push({ role: 'assistant', content: prefixText })
  }
  return messages
}

type Chunk = {
  error?: { message?: string }
  choices?: {
    delta?: { content?: string | null; reasoning_content?: string | null }
    finish_reason?: string | null
  }[]
}

/**
 * POST {baseUrl}/chat/completions（stream: true），逐个产出内部流式事件。
 * DeepSeek / 硅基流动等返回的 reasoning_content 转成思考块；正文转成文本块。
 */
export async function* streamOpenAI(
  profile: ModelProfile,
  apiKey: string,
  messages: OpenAIMessage[],
  signal: AbortSignal,
  sampling?: { temperature?: number; top_p?: number }
): AsyncGenerator<MessageStreamEvent> {
  const base = profile.baseUrl.replace(/\/+$/, '')
  const url = `${base}/chat/completions`
  // 部分模型只接受默认采样参数（例如 Kimi：temperature 必须为 1）
  const strictSampling =
    /moonshot|kimi|reasoner|thinking|o1|o3/i.test(profile.model) ||
    /moonshot\.cn/i.test(base)
  const effective = strictSampling ? undefined : sampling
  const post = (body: unknown) =>
    fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${apiKey}`,
        Accept: 'text/event-stream',
      },
      body: JSON.stringify(body),
      signal,
    })

  let response: Response
  try {
    response = await post({ model: profile.model, messages, stream: true, ...(effective ?? {}) })
    // 未知的严格服务商：400 且提到采样参数时，去掉参数重发一次
    if (!response.ok && effective && response.status === 400) {
      const detail = await response.text().catch(() => '')
      if (/temperature|top_p/i.test(detail)) {
        response = await post({ model: profile.model, messages, stream: true })
      } else {
        throw new ApiError('http', detail.slice(0, 600) || `HTTP 400（${url}）`, 400)
      }
    }
  } catch (error) {
    if (signal.aborted) {
      throw error
    }
    if (error instanceof ApiError) {
      throw error
    }
    const detail = error instanceof Error ? error.message : String(error)
    throw new ApiError('network', `${url}：${detail}`)
  }
  if (!response.ok) {
    let message = `HTTP ${response.status}（${url}）`
    try {
      const text = await response.text()
      if (text) {
        message = text.slice(0, 600)
      }
    } catch {
      // 忽略读取失败，用状态码兜底
    }
    throw new ApiError('http', message, response.status)
  }
  if (!response.body) {
    throw new ApiError('protocol', '响应没有内容')
  }

  let nextIndex = 0
  let thinkingIndex = -1
  let textIndex = -1
  let stopReason: 'end_turn' | 'max_tokens' = 'end_turn'

  for await (const event of readServerSentEvents(response.body, signal)) {
    const raw = event.data.trim()
    if (!raw) {
      continue
    }
    if (raw === '[DONE]') {
      break
    }
    let chunk: Chunk
    try {
      chunk = JSON.parse(raw) as Chunk
    } catch {
      continue
    }
    if (chunk.error?.message) {
      throw new ApiError('stream', chunk.error.message)
    }
    const choice = chunk.choices?.[0]
    if (!choice) {
      continue
    }
    const reasoning = choice.delta?.reasoning_content
    if (typeof reasoning === 'string' && reasoning) {
      if (thinkingIndex < 0) {
        thinkingIndex = nextIndex
        nextIndex += 1
        yield {
          type: 'content_block_start',
          index: thinkingIndex,
          content_block: { type: 'thinking', thinking: '' },
        }
      }
      yield {
        type: 'content_block_delta',
        index: thinkingIndex,
        delta: { type: 'thinking_delta', thinking: reasoning },
      }
    }
    const content = choice.delta?.content
    if (typeof content === 'string' && content) {
      if (textIndex < 0) {
        textIndex = nextIndex
        nextIndex += 1
        yield {
          type: 'content_block_start',
          index: textIndex,
          content_block: { type: 'text', text: '' },
        }
      }
      yield {
        type: 'content_block_delta',
        index: textIndex,
        delta: { type: 'text_delta', text: content },
      }
    }
    if (choice.finish_reason) {
      stopReason = choice.finish_reason === 'length' ? 'max_tokens' : 'end_turn'
    }
  }

  if (thinkingIndex >= 0) {
    yield { type: 'content_block_stop', index: thinkingIndex }
  }
  if (textIndex >= 0) {
    yield { type: 'content_block_stop', index: textIndex }
  }
  yield {
    type: 'message_delta',
    delta: { stop_reason: stopReason, stop_sequence: null },
  }
  yield { type: 'message_stop' }
}
