import { saveFile, type SaveResult } from '../../utils/download.js'
import { getVisibleMessages } from './branches.js'
import type { Message, Session } from './types.js'

const pad = (value: number) => String(value).padStart(2, '0')

const formatTime = (value: number) => {
  const date = new Date(value)
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())} ${pad(
    date.getHours()
  )}:${pad(date.getMinutes())}`
}

const stamp = () => {
  const date = new Date()
  return `${date.getFullYear()}${pad(date.getMonth() + 1)}${pad(date.getDate())}-${pad(
    date.getHours()
  )}${pad(date.getMinutes())}`
}

const messageText = (message: Message): string =>
  message.role === 'user'
    ? message.content
    : message.blocks.map((block) => (block.type === 'text' ? block.text : '')).join('')

/** 生成可读的纯文本对话记录：分隔线 + 序号 + 角色 + 时间 + 正文 */
export const buildSessionText = (session: Session): string => {
  const messages = getVisibleMessages(session)
  const lines: string[] = []
  lines.push('DeepSeek 对话导出')
  lines.push(`标题：${session.title || '未命名对话'}`)
  lines.push(`导出时间：${formatTime(Date.now())}`)
  lines.push(`消息条数：${messages.length}`)
  lines.push('')
  messages.forEach((message, index) => {
    const role = message.role === 'user' ? '用户' : 'AI'
    lines.push('='.repeat(56))
    lines.push(`[${index + 1}] ${role}     ${formatTime(message.createdAt)}`)
    lines.push('='.repeat(56))
    const text = messageText(message).trim()
    if (message.role === 'user' && message.files.length > 0) {
      lines.push(`（附件：${message.files.map((file) => file.name).join('、')}）`)
    }
    lines.push(text || '（无文字内容）')
    lines.push('')
  })
  return lines.join('\n')
}

/** 导出当前会话为 TXT；文件名取会话标题，去掉系统不允许的字符 */
export const exportSessionText = async (session: Session): Promise<SaveResult> => {
  const body = buildSessionText(session)
  const safeTitle = (session.title || '对话')
    .replace(/[\\/:*?"<>|\r\n\t]+/g, '_')
    .trim()
    .slice(0, 30)
  const name = `${safeTitle}-${stamp()}.txt`
  return saveFile(name, new Blob([`\uFEFF${body}`], { type: 'text/plain;charset=utf-8' }))
}
