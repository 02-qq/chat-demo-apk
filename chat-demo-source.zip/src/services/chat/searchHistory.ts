import { useChatStore } from './store.js'
import { getVisibleMessages } from './branches.js'
import * as db from './db.js'
import type { Message, SessionSummary } from './types.js'

/** 全量历史搜索结果：定位到某条具体消息 */
export type HistoryHit = {
  sessionId: string
  title: string
  messageId: string
  role: 'user' | 'assistant'
  snippet: string
  createdAt: number
}

type IndexItem = {
  messageId: string
  role: 'user' | 'assistant'
  text: string
  createdAt: number
}

type CacheEntry = { updatedAt: number; items: IndexItem[] }

/** 会话正文缓存：按 updatedAt 失效，避免每次搜索都整库读 IndexedDB */
const cache = new Map<string, CacheEntry>()

export const clearHistorySearchCache = () => cache.clear()

const plainText = (message: Message): string => {
  if (message.role === 'user') {
    return message.content
  }
  // 模板提示不是模型正文，不参与搜索
  return message.blocks
    .map((block) => (block.type === 'text' && !block.isTemplate ? block.text : ''))
    .join('\n')
}

const indexOfSession = async (summary: SessionSummary): Promise<IndexItem[]> => {
  const cached = cache.get(summary.id)
  if (cached && cached.updatedAt === summary.updatedAt) {
    return cached.items
  }
  const session = await db.loadSession(summary.id)
  // 只索引当前展示的分支，避免搜到点了看不到的历史版本
  const items = (session ? getVisibleMessages(session) : [])
    .map((message) => ({
      messageId: message.id,
      role: message.role,
      text: plainText(message),
      createdAt: message.createdAt,
    }))
    .filter((item) => item.text.trim().length > 0)
  cache.set(summary.id, { updatedAt: summary.updatedAt, items })
  return items
}

const snippetAround = (text: string, index: number, length: number): string => {
  const start = Math.max(0, index - 24)
  const end = Math.min(text.length, index + length + 60)
  const flat = text.slice(start, end).replace(/\s+/g, ' ')
  return `${start > 0 ? '…' : ''}${flat}${end < text.length ? '…' : ''}`
}

/** 在所有会话的消息里做子串搜索，按消息时间倒序返回 */
export const searchHistory = async (query: string, limit = 80): Promise<HistoryHit[]> => {
  const keyword = query.trim().toLowerCase()
  if (keyword.length === 0) {
    return []
  }
  const summaries = useChatStore.getState().sessions
  const hits: HistoryHit[] = []
  for (const summary of summaries) {
    let items: IndexItem[]
    try {
      items = await indexOfSession(summary)
    } catch {
      continue
    }
    for (const item of items) {
      const index = item.text.toLowerCase().indexOf(keyword)
      if (index === -1) {
        continue
      }
      hits.push({
        sessionId: summary.id,
        title: summary.title || '未命名对话',
        messageId: item.messageId,
        role: item.role,
        snippet: snippetAround(item.text, index, keyword.length),
        createdAt: item.createdAt,
      })
    }
  }
  return hits.sort((left, right) => right.createdAt - left.createdAt).slice(0, limit)
}
