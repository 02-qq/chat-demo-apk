import { getVisibleMessages } from './branches.js'
import { getContextRounds } from './reply.js'
import type { Message, Session } from './types.js'

/**
 * 上下文窗口上限（Token）。deepseek-flash 的窗口足够大，这里取保守值做展示基准；
 * 想改成别的数值只改这一行即可。
 */
export const CONTEXT_LIMIT = 128000

const CJK = /[\u3040-\u30ff\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff\uac00-\ud7af]/

/** 粗略估算文本 Token：中日韩字符约 1.5 字一个 Token，其余字符约 4 字符一个 Token。 */
export const estimateTextTokens = (text: string): number => {
  if (!text) {
    return 0
  }
  let cjk = 0
  for (const char of text) {
    if (CJK.test(char)) {
      cjk += 1
    }
  }
  const rest = text.length - cjk
  return Math.ceil(cjk / 1.5 + rest / 4)
}

/** 单条消息进入请求时的估算 Token；历史思考不会回传，因此不计数。 */
const estimateMessage = (message: Message): number => {
  let tokens = 6
  if (message.role === 'user') {
    tokens += estimateTextTokens(message.content)
    for (const file of message.files) {
      tokens += file.isImage ? 800 : 1600
    }
    return Math.round(tokens)
  }
  for (const block of message.blocks) {
    if (block.type === 'text') {
      tokens += estimateTextTokens(block.text)
    }
  }
  return Math.round(tokens)
}

export type ContextUsage = {
  /** 当前上下文估算占用 */
  used: number
  limit: number
  remaining: number
  /** 0-100 */
  percent: number
  /** 计入上下文的消息条数与轮数 */
  messages: number
  rounds: number
  /** 被压缩排除的消息条数 */
  compressed: number
  /** 最近一次请求服务端回报的实际 Token（输入 + 缓存 + 输出） */
  actual?: number
}

export const getContextUsage = (session: Session): ContextUsage => {
  const visible = getVisibleMessages(session)
  const active = visible.filter((message) => !message.excluded)
  let used = 0
  for (const message of active) {
    used += estimateMessage(message)
  }
  let actual: number | undefined
  for (let index = active.length - 1; index >= 0; index -= 1) {
    const message = active[index]
    if (message.role === 'assistant' && message.usage) {
      const usage = message.usage
      actual =
        usage.input_tokens +
        usage.cache_read_input_tokens +
        usage.cache_creation_input_tokens +
        usage.output_tokens
      break
    }
  }
  const limit = CONTEXT_LIMIT
  const percent = limit > 0 ? Math.min(100, (used / limit) * 100) : 0
  return {
    used,
    limit,
    remaining: Math.max(0, limit - used),
    percent,
    messages: active.length,
    rounds: getContextRounds(active).length,
    compressed: visible.length - active.length,
    actual,
  }
}
