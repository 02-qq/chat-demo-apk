import { create } from 'zustand'
import { createId } from '../utils/id.js'
import { useSettings } from './settings.js'

/** deepseek：DeepSeek 原生 anthropic 兼容协议；openai：OpenAI Chat Completions 兼容协议 */
export type ModelProtocol = 'deepseek' | 'openai'

export type ModelProfile = {
  id: string
  /** 界面上显示的名字 */
  name: string
  protocol: ModelProtocol
  /** 接口根地址，不带结尾斜杠；openai 协议要带 /v1 */
  baseUrl: string
  apiKey: string
  /** 模型 id，如 deepseek-flash、moonshot-v1-8k */
  model: string
}

const PROFILES_KEY = 'chat-demo:model-profiles'
const ACTIVE_KEY = 'chat-demo:active-model'

const DEFAULT_PROFILE: ModelProfile = {
  id: 'deepseek-official',
  name: 'DeepSeek 官方',
  protocol: 'deepseek',
  baseUrl: 'https://api.deepseek.com',
  apiKey: '',
  model: 'deepseek-flash',
}

const isProfile = (value: unknown): value is ModelProfile => {
  if (typeof value !== 'object' || value === null) {
    return false
  }
  const item = value as Record<string, unknown>
  return (
    typeof item.id === 'string' &&
    typeof item.name === 'string' &&
    (item.protocol === 'deepseek' || item.protocol === 'openai') &&
    typeof item.baseUrl === 'string' &&
    typeof item.apiKey === 'string' &&
    typeof item.model === 'string'
  )
}

const readProfiles = (): ModelProfile[] => {
  let raw: unknown = null
  try {
    raw = JSON.parse(localStorage.getItem(PROFILES_KEY) ?? 'null')
  } catch {
    raw = null
  }
  const list = Array.isArray(raw) ? raw.filter(isProfile) : []
  return list.length > 0 ? list : [{ ...DEFAULT_PROFILE }]
}

const readActive = (profiles: ModelProfile[]): string => {
  let saved: string | null = null
  try {
    saved = localStorage.getItem(ACTIVE_KEY)
  } catch {
    saved = null
  }
  return profiles.some((profile) => profile.id === saved) ? (saved as string) : profiles[0].id
}

const persist = (profiles: ModelProfile[], activeId: string) => {
  try {
    localStorage.setItem(PROFILES_KEY, JSON.stringify(profiles))
    localStorage.setItem(ACTIVE_KEY, activeId)
  } catch {
    // 存储不可用时只在内存生效
  }
}

const initial = (() => {
  const profiles = readProfiles()
  return { profiles, activeId: readActive(profiles) }
})()

export const useModels = create<{ profiles: ModelProfile[]; activeId: string }>(() => initial)

/** 当前选用的模型配置；列表被删空时回退到内置的 DeepSeek 官方配置 */
export const getActiveProfile = (): ModelProfile => {
  const { profiles, activeId } = useModels.getState()
  return profiles.find((profile) => profile.id === activeId) ?? profiles[0] ?? { ...DEFAULT_PROFILE }
}

/** DeepSeek 协议兼容原有设置里的 API Key：配置里没填就沿用设置页的 Key */
export const getProfileApiKey = (profile: ModelProfile): string =>
  profile.apiKey || (profile.protocol === 'deepseek' ? (useSettings.getState().apiKey ?? '') : '')

export const setActiveModel = (id: string) => {
  const { profiles } = useModels.getState()
  if (!profiles.some((profile) => profile.id === id)) {
    return
  }
  useModels.setState({ activeId: id })
  persist(profiles, id)
}

export const addProfile = (input: Omit<ModelProfile, 'id'>): ModelProfile => {
  const profile: ModelProfile = {
    ...input,
    id: createId(),
    baseUrl: input.baseUrl.trim().replace(/\/+$/, ''),
    model: input.model.trim(),
    name: input.name.trim() || input.model.trim() || '未命名模型',
  }
  const { profiles, activeId } = useModels.getState()
  const next = [...profiles, profile]
  useModels.setState({ profiles: next, activeId: profile.id })
  persist(next, profile.id)
  return profile
}

export const updateProfile = (id: string, patch: Partial<Omit<ModelProfile, 'id'>>) => {
  const { profiles, activeId } = useModels.getState()
  const next = profiles.map((profile) =>
    profile.id === id
      ? {
          ...profile,
          ...patch,
          baseUrl: (patch.baseUrl ?? profile.baseUrl).trim().replace(/\/+$/, ''),
        }
      : profile
  )
  useModels.setState({ profiles: next })
  persist(next, activeId)
}

export const removeProfile = (id: string) => {
  const { profiles } = useModels.getState()
  const next = profiles.filter((profile) => profile.id !== id)
  if (next.length === 0) {
    return
  }
  const activeId = next.some((profile) => profile.id === id) ? next[0].id : useModels.getState().activeId
  useModels.setState({ profiles: next, activeId })
  persist(next, activeId)
}
