import { useTranslate } from '../../i18n/index.js'
import clsx from 'clsx'
import { memo, useState } from 'react'
import type { CSSProperties } from 'react'
import {
  IconEditOutline16,
  IconRefreshOutline16,
  IconTrashOutline16,
  IconWarningOutline16,
} from '../base/icons.js'
import { describeReply } from '../../services/chat/describe.js'
import { canContinueReply } from '../../services/chat/reply.js'
import { continueReply, deleteMessages, editReply, regenerateReply } from '../../services/chat/store.js'
import { stopReadAloud } from '../../services/speech/readAloud.js'
import type { AssistantMessage as AssistantMessageType } from '../../services/chat/types.js'
import { openSettings } from '../settings/settingsDialogState.js'
import { IconButton } from '../base/IconButton.js'
import { Button } from '../base/Button.js'
import { showToast } from '../base/toastState.js'
import { openModelDialog } from '../session/modelDialogState.js'
import { Markdown } from '../markdown/Markdown.js'
import { SiteThumbnails } from '../search/SiteLogo.js'
import { toggleSearchPanel, useSearchPanel } from '../search/searchPanelState.js'
import { ReadAloudButton } from './ReadAloudButton.js'
import { CopyButton } from './CopyButton.js'
import { ReplyArea } from './ReplyArea.js'
import { useReplyView } from './useReplyView.js'
import {
  BranchSwitcher,
  type MessageVersions,
  type SelectMessageVersion,
} from './BranchSwitcher.js'
import styles from './AssistantMessage.module.css'

const TOP_UP_URL = 'https://platform.deepseek.com/top_up'

const editorStyle: CSSProperties = {
  boxSizing: 'border-box',
  width: '100%',
  minHeight: 140,
  padding: '10px 12px',
  border: '1px solid var(--dsw-alias-bg-skeleton, rgba(0, 0, 0, 0.16))',
  borderRadius: 10,
  background: 'var(--dsw-alias-bg-base, transparent)',
  color: 'var(--dsw-alias-label-primary, inherit)',
  font: 'inherit',
  lineHeight: '26px',
  resize: 'vertical',
}

export const AssistantMessage = memo(function AssistantMessage({
  sessionId,
  message,
  isLast,
  streaming,
  busy,
  versions,
  onSelectVersion,
}: {
  sessionId: string
  message: AssistantMessageType
  isLast: boolean
  streaming: boolean
  busy: boolean
  versions: MessageVersions
  onSelectVersion: SelectMessageVersion
}) {
  const t = useTranslate()
  const view = useReplyView(message, streaming)
  const panelEntry = useSearchPanel((state) => state.entry)
  const notice = streaming ? null : describeReply(message)
  // 安全拒绝：已下发的思考与正文按协议丢弃，只显示模板答复。
  const refused = message.stopReason === 'refusal'
  const answer = refused ? null : view.answer
  /** 被中断时保留下来的半截正文 */
  const partial = refused ? view.answer : null
  const responseText = [answer?.text, notice?.presentation === 'response' ? notice.text : null]
    .filter(Boolean)
    .join('\n\n')
  const copyText = responseText || notice?.text
  const waiting = streaming && view.steps.length === 0 && !view.answer && !message.thinking
  const summaryEntry = `${message.id}-summary`
  const [editing, setEditing] = useState(false)
  const [draft, setDraft] = useState('')

  const startEditing = () => {
    setDraft(responseText)
    setEditing(true)
  }

  const saveEdit = () => {
    if (editReply(sessionId, message.id, draft)) {
      setEditing(false)
      showToast('已更新这条回答')
    } else {
      showToast('保存失败，请稍后重试')
    }
  }

  const removeMessage = () => {
    if (!window.confirm('删除这条回答？该操作不可撤销。')) {
      return
    }
    if (deleteMessages(sessionId, [message.id])) {
      showToast('已删除')
    } else {
      showToast('删除失败，请稍后重试')
    }
  }

  return (
    <div className={styles.message} data-mid={message.id}>
      {refused ? null : (
        <ReplyArea
          message={message}
          view={view}
          streaming={streaming}
          hasResponse={!!responseText}
        />
      )}
      {refused ? (
        <div className={styles.refused}>
          <div className={styles.refusedTitle}>这条回答被中断了（内容不完整）</div>
          <div className={styles.refusedText}>
            {notice?.text || '服务端在生成过程中终止了回复，已收到的部分保留在下面。'}
          </div>
          {partial ? (
            <div className={styles.refusedPartial}>
              <div className={styles.refusedLabel}>中断前已经收到的内容</div>
              <Markdown
                className="ds-assistant-message-main-content"
                content={partial.markdown}
                loading={false}
                cacheKey={`${message.id}-partial`}
                disableLink={false}
                sources={view.sources}
              />
            </div>
          ) : null}
          <div className={styles.refusedActions}>
            <Button size="s" variant="outlined" onClick={openModelDialog}>
              换个模型
            </Button>
            <Button
              size="s"
              variant="outlined"
              disabled={busy}
              onClick={() => {
                stopReadAloud()
                regenerateReply(sessionId, message.id)
              }}
            >
              重说一次
            </Button>
          </div>
          <div className={styles.refusedHint}>
            这段内容不会进入后续上下文；换一个服务商的模型重问，通常能拿到完整回答。
          </div>
        </div>
      ) : null}
      {editing ? (
        <div>
          <textarea
            aria-label="编辑回答"
            style={editorStyle}
            value={draft}
            disabled={busy}
            onChange={(event) => setDraft(event.target.value)}
          />
          <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end', marginTop: 8 }}>
            <Button size="s" variant="outlined" onClick={() => setEditing(false)}>
              取消
            </Button>
            <Button size="s" disabled={busy || !draft.trim()} onClick={saveEdit}>
              保存
            </Button>
          </div>
        </div>
      ) : answer ? (
        <Markdown
          className="ds-assistant-message-main-content"
          content={answer.markdown}
          loading={streaming}
          cacheKey={message.id}
          disableLink={false}
          sources={view.sources}
        />
      ) : null}
      {waiting ? (
        <div className={styles.waiting}>
          {[0, 1, 2].map((index) => (
            <span key={index} className={styles.waitingDot} />
          ))}
        </div>
      ) : null}
      {refused ? null : notice?.presentation === 'response' ? (
        <Markdown
          className="ds-assistant-message-main-content"
          content={notice.text}
          loading={false}
          cacheKey={`${message.id}-template`}
          disableLink={false}
        />
      ) : notice ? (
        <div className={styles.notice}>
          <IconWarningOutline16 />
          <span>
            {notice.text}
            {notice.action === 'apiKey' ? (
              <>
                {' '}
                <button
                  type="button"
                  className={styles.noticeAction}
                  onClick={() => openSettings('data')}
                >
                  {t('changeApiKey')}
                </button>
              </>
            ) : null}
            {notice.action === 'topUp' ? (
              <>
                {' '}
                <a
                  className={styles.noticeAction}
                  href={TOP_UP_URL}
                  target="_blank"
                  rel="noreferrer"
                >
                  {t('topUp')}
                </a>
              </>
            ) : null}
          </span>
        </div>
      ) : null}
      {!streaming && !refused && view.searchResults.length > 0 ? (
        <div
          className={clsx(styles.summary, panelEntry === summaryEntry && styles.summaryActive)}
          onClick={() => toggleSearchPanel(summaryEntry, view.searchResults)}
        >
          <SiteThumbnails sources={view.searchResults} />
          <span>
            {t(
              view.searchResults.length === 1 ? 'messageSearchSummary' : 'messageSearchSummaries',
              { count: view.searchResults.length }
            )}
          </span>
        </div>
      ) : null}
      {streaming || editing ? null : (
        <div className={styles.bottom}>
          <BranchSwitcher versions={versions} disabled={busy} onSelect={onSelectVersion} />
          <div className={clsx(styles.actions, isLast && styles.alwaysShow)}>
            {isLast && message.provider ? (
              <span className={styles.providerTag} title="生成这条回答时使用的模型">
                {message.provider}
              </span>
            ) : null}
            {copyText ? <CopyButton text={copyText} /> : null}
            {responseText && !refused ? (
              <ReadAloudButton messageId={message.id} text={responseText} />
            ) : null}
            {refused ? null : (
              <IconButton
                icon={<IconEditOutline16 />}
                tooltip="编辑回答"
                tooltipPlacement="bottom"
                disabled={busy || !responseText}
                onClick={startEditing}
              />
            )}
            <IconButton
              icon={<IconRefreshOutline16 />}
              tooltip={t('regenerate')}
              tooltipPlacement="bottom"
              disabled={busy || refused}
              onClick={() => {
                stopReadAloud()
                regenerateReply(sessionId, message.id)
              }}
            />
            <IconButton
              icon={<IconTrashOutline16 />}
              tooltip="删除这条"
              tooltipPlacement="bottom"
              disabled={busy}
              onClick={removeMessage}
            />
          </div>
          {isLast && canContinueReply(message) ? (
            <Button
              variant="outlined"
              size="s"
              className={styles.continueButton}
              disabled={busy}
              onClick={() => {
                stopReadAloud()
                continueReply(sessionId, message.id)
              }}
            >
              {t('continueGenerating')}
            </Button>
          ) : null}
        </div>
      )}
    </div>
  )
})
