import { create } from 'zustand'

/** 搜索命中的消息：让消息列表滚动到它并闪一下 */
type FocusState = {
  messageId: string | null
  /** 同一个 id 再次命中时也要重新触发，用序号驱动 */
  seq: number
  focus: (messageId: string) => void
  clear: () => void
}

export const useFocusMessage = create<FocusState>((set) => ({
  messageId: null,
  seq: 0,
  focus: (messageId) => set((state) => ({ messageId, seq: state.seq + 1 })),
  clear: () => set({ messageId: null }),
}))
