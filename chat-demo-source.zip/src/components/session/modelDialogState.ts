import { create } from 'zustand'

/** 模型弹窗的全局开关：设置面板、上下文面板、被中断的回答都能打开它 */
export const useModelDialog = create(() => ({ open: false }))

export const openModelDialog = () => useModelDialog.setState({ open: true })

export const closeModelDialog = () => useModelDialog.setState({ open: false })
