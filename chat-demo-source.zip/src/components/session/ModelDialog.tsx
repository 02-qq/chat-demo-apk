import { useState } from 'react'
import { streamMessage } from '../../services/api/client.js'
import { streamOpenAI } from '../../services/api/openai.js'
import type { ChatModel, CreateMessageRequest } from '../../services/api/types.js'
import {
  addProfile,
  getProfileApiKey,
  removeProfile,
  setActiveModel,
  updateProfile,
  useModels,
  type ModelProfile,
  type ModelProtocol,
} from '../../services/models.js'
import { useSettings } from '../../services/settings.js'
import { Button } from '../base/Button.js'
import { showToast } from '../base/toastState.js'
import styles from './ModelDialog.module.css'

type Preset = { label: string; protocol: ModelProtocol; baseUrl: string; model: string }

const PRESETS: Preset[] = [
  {
    label: '硅基流动',
    protocol: 'openai',
    baseUrl: 'https://api.siliconflow.cn/v1',
    model: 'deepseek-ai/DeepSeek-V3',
  },
  {
    label: '月之暗面 Kimi',
    protocol: 'openai',
    baseUrl: 'https://api.moonshot.cn/v1',
    model: 'moonshot-v1-8k',
  },
  {
    label: '智谱 GLM',
    protocol: 'openai',
    baseUrl: 'https://open.bigmodel.cn/api/paas/v4',
    model: 'glm-4-flash',
  },
  {
    label: '通义千问',
    protocol: 'openai',
    baseUrl: 'https://dashscope.aliyuncs.com/compatible-mode/v1',
    model: 'qwen-plus',
  },
  { label: 'OpenAI', protocol: 'openai', baseUrl: 'https://api.openai.com/v1', model: 'gpt-4o-mini' },
]

const protocolLabel = (protocol: ModelProtocol) =>
  protocol === 'deepseek' ? 'DeepSeek 原生' : 'OpenAI 兼容'

const endpointOf = (profile: ModelProfile) =>
  profile.protocol === 'openai'
    ? `${profile.baseUrl.replace(/\/+$/, '')}/chat/completions`
    : `${profile.baseUrl.replace(/\/+$/, '')}/anthropic/v1/messages`

/** 模型管理：切换、测试、编辑、从服务商拉取模型列表 */
export const ModelDialog = ({ open, onClose }: { open: boolean; onClose: () => void }) => {
  const profiles = useModels((state) => state.profiles)
  const activeId = useModels((state) => state.activeId)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [name, setName] = useState('')
  const [protocol, setProtocol] = useState<ModelProtocol>('openai')
  const [baseUrl, setBaseUrl] = useState('https://api.siliconflow.cn/v1')
  const [model, setModel] = useState('')
  const [apiKey, setApiKey] = useState('')
  const [models, setModels] = useState<string[]>([])
  const [testing, setTesting] = useState<string | null>(null)
  const [fetching, setFetching] = useState(false)

  if (!open) {
    return null
  }

  const resetForm = () => {
    setEditingId(null)
    setName('')
    setModel('')
    setApiKey('')
    setModels([])
  }

  const usePreset = (preset: Preset) => {
    setProtocol(preset.protocol)
    setBaseUrl(preset.baseUrl)
    setModel(preset.model)
    setName((current: string) => (current.trim() ? current : preset.label))
  }

  const startEdit = (profile: ModelProfile) => {
    setEditingId(profile.id)
    setName(profile.name)
    setProtocol(profile.protocol)
    setBaseUrl(profile.baseUrl)
    setModel(profile.model)
    setApiKey(profile.apiKey)
    setModels([])
  }

  const keyForForm = () =>
    apiKey.trim() ||
    (protocol === 'deepseek' ? (useSettings.getState().apiKey ?? '') : '')

  /** 从服务商的 /models 读取可用模型，填进下拉候选 */
  const fetchModels = async () => {
    const base = baseUrl.trim().replace(/\/+$/, '')
    if (!base) {
      showToast('先填接口地址')
      return
    }
    setFetching(true)
    try {
      const response = await fetch(`${base}/models`, {
        headers: { Authorization: `Bearer ${keyForForm()}` },
      })
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`)
      }
      const data = (await response.json()) as { data?: { id?: unknown }[] }
      const list = (data.data ?? [])
        .map((item) => item.id)
        .filter((id): id is string => typeof id === 'string' && id.length > 0)
      setModels(list)
      showToast(list.length > 0 ? `拿到 ${list.length} 个模型，点模型名可以选` : '服务商没有返回模型列表')
    } catch (error) {
      showToast(`拉取失败：${error instanceof Error ? error.message : String(error)}`)
    } finally {
      setFetching(false)
    }
  }

  const submit = () => {
    if (!baseUrl.trim() || !model.trim()) {
      showToast('请填写接口地址和模型名')
      return
    }
    if (editingId) {
      updateProfile(editingId, { name, protocol, baseUrl, model, apiKey })
      showToast('已保存修改')
    } else {
      addProfile({ name, protocol, baseUrl, model, apiKey })
      showToast('已添加并切换到这个模型')
    }
    resetForm()
  }

  const activate = (profile: ModelProfile) => {
    setActiveModel(profile.id)
    showToast(`已切换到 ${profile.name}`)
    onClose()
  }

  /** 用这个配置真实发一次极短请求，验证地址与 Key */
  const testProfile = async (profile: ModelProfile) => {
    const key = getProfileApiKey(profile)
    if (!key) {
      showToast('这个模型还没有填 API Key')
      return
    }
    setTesting(profile.id)
    const started = Date.now()
    try {
      const controller = new AbortController()
      const events =
        profile.protocol === 'openai'
          ? streamOpenAI(
              profile,
              key,
              [{ role: 'user', content: '只回复两个字：可用' }],
              controller.signal
            )
          : streamMessage(
              key,
              {
                model: (profile.model || 'deepseek-flash') as ChatModel,
                system: '你是一个 AI 助手。',
                messages: [{ role: 'user', content: '只回复两个字：可用' }],
                thinking: { type: 'disabled' },
                safety_check: { level: 'high' },
                tools: [],
              } as CreateMessageRequest,
              controller.signal,
              profile.baseUrl
            )
      let received = false
      for await (const event of events) {
        if (event.type === 'content_block_start' || event.type === 'content_block_delta') {
          received = true
          break
        }
      }
      showToast(received ? `✓ 可用（${Date.now() - started} ms）` : '已连通，但没有返回内容')
    } catch (error) {
      showToast(`✗ ${error instanceof Error ? error.message : String(error)}`)
    } finally {
      setTesting(null)
    }
  }

  return (
    <div className={styles.overlay} role="dialog" aria-label="模型管理" onClick={onClose}>
      <div className={styles.card} onClick={(event) => event.stopPropagation()}>
        <h2 className={styles.title}>模型</h2>
        <p className={styles.subtitle}>
          切换后新消息立即使用所选模型，回答下方会标注实际使用的模型。点「编辑」可以改同一个服务商的模型名，不用删了重建。
        </p>

        <div className={styles.list}>
          {profiles.map((profile) => (
            <div
              key={profile.id}
              className={`${styles.item} ${profile.id === activeId ? styles.itemOn : ''}`}
            >
              <div className={styles.itemMain}>
                <div className={styles.itemName}>{profile.name}</div>
                <div className={styles.itemMeta}>
                  {profile.model} · {protocolLabel(profile.protocol)}
                </div>
                <div className={styles.itemMeta}>{endpointOf(profile)}</div>
              </div>
              <div className={styles.itemButtons}>
                <Button
                  size="s"
                  variant="outlined"
                  disabled={testing !== null}
                  onClick={() => void testProfile(profile)}
                >
                  {testing === profile.id ? '测试中…' : '测试'}
                </Button>
                <Button
                  size="s"
                  variant="outlined"
                  onClick={() => startEdit(profile)}
                >
                  编辑
                </Button>
                {profile.id === activeId ? (
                  <Button size="s" variant="outlined" disabled>
                    使用中
                  </Button>
                ) : (
                  <Button size="s" variant="outlined" onClick={() => activate(profile)}>
                    切换
                  </Button>
                )}
                <Button
                  size="s"
                  variant="dangerOutlined"
                  disabled={profiles.length <= 1}
                  onClick={() => {
                    removeProfile(profile.id)
                    if (editingId === profile.id) {
                      resetForm()
                    }
                    showToast('已删除')
                  }}
                >
                  删除
                </Button>
              </div>
            </div>
          ))}
        </div>

        <div className={styles.section}>
          <div className={styles.formTitle}>
            {editingId ? '编辑模型' : '添加模型'}
            {editingId ? (
              <button type="button" className={styles.linkBtn} onClick={resetForm}>
                取消编辑
              </button>
            ) : null}
          </div>
          <div className={styles.presets}>
            {PRESETS.map((preset) => (
              <button
                key={preset.label}
                type="button"
                className={styles.preset}
                onClick={() => usePreset(preset)}
              >
                {preset.label}
              </button>
            ))}
          </div>
          <div className={styles.row}>
            <div className={styles.field} style={{ flex: 1 }}>
              <span className={styles.label}>显示名称</span>
              <input
                className={styles.input}
                value={name}
                placeholder="例如：硅基流动"
                onChange={(event) => setName(event.target.value)}
              />
            </div>
            <div className={styles.field} style={{ flex: 1 }}>
              <span className={styles.label}>协议</span>
              <select
                className={styles.select}
                value={protocol}
                onChange={(event) => setProtocol(event.target.value as ModelProtocol)}
              >
                <option value="openai">OpenAI 兼容</option>
                <option value="deepseek">DeepSeek 原生</option>
              </select>
            </div>
          </div>
          <div className={styles.field}>
            <span className={styles.label}>接口地址</span>
            <input
              className={styles.input}
              value={baseUrl}
              placeholder="https://api.siliconflow.cn/v1"
              onChange={(event) => setBaseUrl(event.target.value)}
            />
          </div>
          <div className={styles.row}>
            <div className={styles.field} style={{ flex: 1 }}>
              <span className={styles.label}>模型名</span>
              <input
                className={styles.input}
                value={model}
                list="chat-demo-model-options"
                placeholder="deepseek-ai/DeepSeek-V3"
                onChange={(event) => setModel(event.target.value)}
              />
              <datalist id="chat-demo-model-options">
                {models.map((item) => (
                  <option key={item} value={item} />
                ))}
              </datalist>
            </div>
            <div className={styles.field} style={{ flex: 1 }}>
              <span className={styles.label}>API Key</span>
              <input
                className={styles.input}
                type="password"
                value={apiKey}
                placeholder="sk-..."
                onChange={(event) => setApiKey(event.target.value)}
              />
            </div>
          </div>
          <div className={styles.row}>
            <Button size="s" variant="outlined" disabled={fetching} onClick={() => void fetchModels()}>
              {fetching ? '拉取中…' : '拉取模型列表'}
            </Button>
            <Button size="s" variant="outlined" onClick={onClose}>
              关闭
            </Button>
            <Button size="s" onClick={submit}>
              {editingId ? '保存修改' : '添加并切换'}
            </Button>
          </div>
          <p className={styles.subtitle} style={{ marginTop: 8, marginBottom: 0 }}>
            模型名可以手填，也可以点「拉取模型列表」从服务商读取（会用上面的地址和 Key）。
          </p>
        </div>
      </div>
    </div>
  )
}
