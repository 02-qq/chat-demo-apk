import { useState } from 'react'
import {
  addProfile,
  removeProfile,
  setActiveModel,
  useModels,
  type ModelProfile,
  type ModelProtocol,
} from '../../services/models.js'
import { Button } from '../base/Button.js'
import { showToast } from '../base/toastState.js'
import styles from './ModelDialog.module.css'

type Preset = { label: string; protocol: ModelProtocol; baseUrl: string; model: string }

const PRESETS: Preset[] = [
  { label: 'DeepSeek', protocol: 'openai', baseUrl: 'https://api.deepseek.com/v1', model: 'deepseek-chat' },
  {
    label: '硅基流动',
    protocol: 'openai',
    baseUrl: 'https://api.siliconflow.cn/v1',
    model: 'deepseek-ai/DeepSeek-V3',
  },
  {
    label: '月之暗面 Kimi',
    protocol: 'openai',
    baseUrl: 'https://api.moonshot.cn/v1',
    model: 'moonshot-v1-8k',
  },
  {
    label: '智谱 GLM',
    protocol: 'openai',
    baseUrl: 'https://open.bigmodel.cn/api/paas/v4',
    model: 'glm-4-flash',
  },
  {
    label: '通义千问',
    protocol: 'openai',
    baseUrl: 'https://dashscope.aliyuncs.com/compatible-mode/v1',
    model: 'qwen-plus',
  },
  { label: 'OpenAI', protocol: 'openai', baseUrl: 'https://api.openai.com/v1', model: 'gpt-4o-mini' },
]

const protocolLabel = (protocol: ModelProtocol) =>
  protocol === 'deepseek' ? 'DeepSeek 原生' : 'OpenAI 兼容'

/** 模型管理：查看已配置的模型、切换当前使用、添加或删除 */
export const ModelDialog = ({ open, onClose }: { open: boolean; onClose: () => void }) => {
  const profiles = useModels((state) => state.profiles)
  const activeId = useModels((state) => state.activeId)
  const [name, setName] = useState('')
  const [protocol, setProtocol] = useState<ModelProtocol>('openai')
  const [baseUrl, setBaseUrl] = useState('https://api.siliconflow.cn/v1')
  const [model, setModel] = useState('')
  const [apiKey, setApiKey] = useState('')

  if (!open) {
    return null
  }

  const usePreset = (preset: Preset) => {
    setProtocol(preset.protocol)
    setBaseUrl(preset.baseUrl)
    setModel(preset.model)
    setName((current: string) => (current.trim() ? current : preset.label))
  }

  const submit = () => {
    if (!baseUrl.trim() || !model.trim()) {
      showToast('请填写接口地址和模型名')
      return
    }
    addProfile({ name, protocol, baseUrl, model, apiKey })
    showToast('已添加并切换到这个模型')
    setName('')
    setModel('')
    setApiKey('')
  }

  const activate = (profile: ModelProfile) => {
    setActiveModel(profile.id)
    showToast(`已切换到 ${profile.name}`)
    onClose()
  }

  return (
    <div className={styles.overlay} role="dialog" aria-label="模型管理" onClick={onClose}>
      <div className={styles.card} onClick={(event) => event.stopPropagation()}>
        <h2 className={styles.title}>模型</h2>
        <p className={styles.subtitle}>
          支持 DeepSeek 原生协议和 OpenAI 兼容协议（大多数国内服务商都提供兼容接口）。切换到某个模型后，下一条消息就用它回答。
        </p>
        <div className={styles.list}>
          {profiles.map((profile) => (
            <div
              key={profile.id}
              className={`${styles.item} ${profile.id === activeId ? styles.itemOn : ''}`}
            >
              <div className={styles.itemMain}>
                <div className={styles.itemName}>{profile.name}</div>
                <div className={styles.itemMeta}>
                  {profile.model} · {protocolLabel(profile.protocol)}
                </div>
              </div>
              {profile.id === activeId ? (
                <Button size="s" variant="outlined" disabled>
                  使用中
                </Button>
              ) : (
                <Button size="s" variant="outlined" onClick={() => activate(profile)}>
                  切换
                </Button>
              )}
              <Button
                size="s"
                variant="dangerOutlined"
                disabled={profiles.length <= 1}
                onClick={() => {
                  removeProfile(profile.id)
                  showToast('已删除')
                }}
              >
                删除
              </Button>
            </div>
          ))}
        </div>

        <div className={styles.section}>
          <div className={styles.presets}>
            {PRESETS.map((preset) => (
              <button
                key={preset.label}
                type="button"
                className={styles.preset}
                onClick={() => usePreset(preset)}
              >
                {preset.label}
              </button>
            ))}
          </div>
          <div className={styles.row}>
            <div className={styles.field} style={{ flex: 1 }}>
              <span className={styles.label}>显示名称</span>
              <input
                className={styles.input}
                value={name}
                placeholder="例如：Kimi"
                onChange={(event) => setName(event.target.value)}
              />
            </div>
            <div className={styles.field} style={{ flex: 1 }}>
              <span className={styles.label}>协议</span>
              <select
                className={styles.select}
                value={protocol}
                onChange={(event) => setProtocol(event.target.value as ModelProtocol)}
              >
                <option value="openai">OpenAI 兼容</option>
                <option value="deepseek">DeepSeek 原生</option>
              </select>
            </div>
          </div>
          <div className={styles.field}>
            <span className={styles.label}>接口地址</span>
            <input
              className={styles.input}
              value={baseUrl}
              placeholder="https://api.example.com/v1"
              onChange={(event) => setBaseUrl(event.target.value)}
            />
          </div>
          <div className={styles.row}>
            <div className={styles.field} style={{ flex: 1 }}>
              <span className={styles.label}>模型名</span>
              <input
                className={styles.input}
                value={model}
                placeholder="deepseek-chat"
                onChange={(event) => setModel(event.target.value)}
              />
            </div>
            <div className={styles.field} style={{ flex: 1 }}>
              <span className={styles.label}>API Key</span>
              <input
                className={styles.input}
                type="password"
                value={apiKey}
                placeholder="sk-..."
                onChange={(event) => setApiKey(event.target.value)}
              />
            </div>
          </div>
          <div className={styles.footer}>
            <Button size="s" variant="outlined" onClick={onClose}>
              关闭
            </Button>
            <Button size="s" onClick={submit}>
              添加并切换
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
