import { useEffect, useRef, useState } from 'react'
import { getContextUsage } from '../../services/chat/context.js'
import { compressSession, restoreContext } from '../../services/chat/store.js'
import type { Session } from '../../services/chat/types.js'
import { Button } from '../base/Button.js'
import { showToast } from '../base/toastState.js'
import { useMessageSelection } from '../messages/messageSelection.js'
import styles from './ContextMeter.module.css'

const RADIUS = 15
const CIRCUMFERENCE = 2 * Math.PI * RADIUS

const formatTokens = (value: number) =>
  value >= 1000 ? `${(value / 1000).toFixed(1)}k` : `${value}`

const formatFull = (value: number) => value.toLocaleString('zh-CN')

/** 顶栏的上下文配额环：点击展开用量详情，并提供压缩上下文、展开历史与批量删除入口 */
export const ContextMeter = ({ session }: { session: Session }) => {
  const [open, setOpen] = useState(false)
  const [busy, setBusy] = useState(false)
  const rootRef = useRef<HTMLDivElement>(null)
  const startSelection = useMessageSelection((state) => state.start)
  const usage = getContextUsage(session)
  const percent = Math.min(100, usage.percent)
  const dash = Math.max(0.4, (CIRCUMFERENCE * percent) / 100)
  const danger = percent >= 85

  useEffect(() => {
    if (!open) {
      return
    }
    const onPointerDown = (event: MouseEvent) => {
      const root = rootRef.current
      if (root && !root.contains(event.target as Node)) {
        setOpen(false)
      }
    }
    document.addEventListener('mousedown', onPointerDown)
    return () => document.removeEventListener('mousedown', onPointerDown)
  }, [open])

  const handleCompress = async () => {
    setBusy(true)
    try {
      const done = await compressSession(session.id)
      showToast(done ? '上下文已压缩，历史已折叠' : '压缩失败：请检查 API Key 或网络后重试')
      if (done) {
        setOpen(false)
      }
    } finally {
      setBusy(false)
    }
  }

  const handleRestore = () => {
    if (restoreContext(session.id)) {
      showToast('已展开完整的对话历史')
      setOpen(false)
    } else {
      showToast('展开失败，请稍后重试')
    }
  }

  return (
    <div className={styles.wrap} ref={rootRef}>
      <button
        type="button"
        className={styles.ring}
        aria-label="上下文用量"
        aria-expanded={open}
        onClick={() => setOpen((value) => !value)}
      >
        <svg className={styles.svg} viewBox="0 0 40 40" aria-hidden="true">
          <circle className={styles.track} cx="20" cy="20" r={RADIUS} />
          <circle
            className={styles.progress}
            cx="20"
            cy="20"
            r={RADIUS}
            style={{
              strokeDasharray: `${dash} ${CIRCUMFERENCE}`,
              stroke: danger ? 'var(--dsw-alias-state-error-primary, #e5484d)' : undefined,
            }}
          />
        </svg>
        <span className={styles.label}>{Math.round(percent)}%</span>
      </button>
      {open ? (
        <div className={styles.panel} role="dialog" aria-label="上下文详情">
          <div className={styles.row}>
            <span className={styles.title}>上下文用量</span>
            <span className={styles.value}>{Math.round(percent)}%</span>
          </div>
          <div className={styles.bar}>
            <div
              className={styles.barFill}
              style={{
                width: `${percent}%`,
                background: danger ? 'var(--dsw-alias-state-error-primary, #e5484d)' : undefined,
              }}
            />
          </div>
          <div className={styles.line}>
            <span>已用（估算）</span>
            <b>{formatFull(usage.used)}</b>
          </div>
          <div className={styles.line}>
            <span>剩余</span>
            <b>{formatFull(usage.remaining)}</b>
          </div>
          <div className={styles.line}>
            <span>窗口上限</span>
            <b>{formatFull(usage.limit)}</b>
          </div>
          <div className={styles.line}>
            <span>计入上下文</span>
            <b>
              {usage.messages} 条 / {usage.rounds} 轮
            </b>
          </div>
          {usage.actual === undefined ? null : (
            <div className={styles.line}>
              <span>上次请求实耗</span>
              <b>{formatFull(usage.actual)}</b>
            </div>
          )}
          {usage.compressed > 0 ? (
            <div className={styles.hint}>
              已有 {usage.compressed} 条历史被压缩，不再进入后续对话（{formatTokens(usage.used)}{' '}
              Token 在上下文中）。
            </div>
          ) : null}
          <div className={styles.actions}>
            <Button size="s" variant="outlined" disabled={busy} onClick={handleCompress}>
              {busy ? '压缩中…' : '压缩上下文'}
            </Button>
            {usage.compressed > 0 ? (
              <Button size="s" variant="outlined" disabled={busy} onClick={handleRestore}>
                展开历史
              </Button>
            ) : null}
          </div>
          <div className={styles.actions}>
            <Button
              size="s"
              variant="outlined"
              onClick={() => {
                setOpen(false)
                startSelection()
              }}
            >
              批量删除消息
            </Button>
          </div>
        </div>
      ) : null}
    </div>
  )
}
