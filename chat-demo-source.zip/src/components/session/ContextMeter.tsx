import { useEffect, useRef, useState } from 'react'
import type { ChangeEvent, CSSProperties } from 'react'
import { getContextUsage } from '../../services/chat/context.js'
import { exportSessionText } from '../../services/chat/exportText.js'
import {
  compressSession,
  restoreContext,
  setSessionBackground,
  useChatStore,
} from '../../services/chat/store.js'
import type { Session } from '../../services/chat/types.js'
import { getActiveProfile } from '../../services/models.js'
import { Button } from '../base/Button.js'
import { showToast } from '../base/toastState.js'
import { useMessageSelection } from '../messages/messageSelection.js'
import { openModelDialog } from './modelDialogState.js'
import styles from './ContextMeter.module.css'

const RADIUS = 15
const CIRCUMFERENCE = 2 * Math.PI * RADIUS

const formatFull = (value: number) => value.toLocaleString('zh-CN')

/** 把用户选的图片压到 1600px 以内再存，避免把几十兆的原图塞进 IndexedDB */
const compressImage = (file: File): Promise<string> =>
  new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file)
    const image = new Image()
    image.onload = () => {
      try {
        const max = 1600
        const scale = Math.min(1, max / Math.max(image.width, image.height))
        const canvas = document.createElement('canvas')
        canvas.width = Math.max(1, Math.round(image.width * scale))
        canvas.height = Math.max(1, Math.round(image.height * scale))
        const context = canvas.getContext('2d')
        if (!context) {
          reject(new Error('canvas unavailable'))
          return
        }
        context.drawImage(image, 0, 0, canvas.width, canvas.height)
        resolve(canvas.toDataURL('image/jpeg', 0.72))
      } catch (error) {
        reject(error instanceof Error ? error : new Error('image failed'))
      } finally {
        URL.revokeObjectURL(url)
      }
    }
    image.onerror = () => {
      URL.revokeObjectURL(url)
      reject(new Error('image load failed'))
    }
    image.src = url
  })

const rowStyle: CSSProperties = { display: 'flex', alignItems: 'center', gap: 8 }

/** 顶栏的上下文配额环：点开是会话面板（用量、压缩、导出、背景、模型、批量删除） */
export const ContextMeter = ({ session }: { session: Session }) => {
  const [open, setOpen] = useState(false)
  const [busy, setBusy] = useState(false)
  const rootRef = useRef<HTMLDivElement>(null)
  const fileRef = useRef<HTMLInputElement>(null)
  const startSelection = useMessageSelection((state) => state.start)
  const activeId = useChatStore((state) => state.activeId)
  const profile = getActiveProfile()
  const usage = getContextUsage(session)
  const percent = Math.min(100, usage.percent)
  const dash = Math.max(0.4, (CIRCUMFERENCE * percent) / 100)
  const danger = percent >= 85

  useEffect(() => {
    if (!open) {
      return
    }
    const onPointerDown = (event: MouseEvent) => {
      const root = rootRef.current
      if (root && !root.contains(event.target as Node)) {
        setOpen(false)
      }
    }
    document.addEventListener('mousedown', onPointerDown)
    return () => document.removeEventListener('mousedown', onPointerDown)
  }, [open])

  // 换会话时收起面板，避免状态串到别的对话
  useEffect(() => {
    setOpen(false)
  }, [activeId])

  const handleCompress = async () => {
    setBusy(true)
    try {
      const done = await compressSession(session.id)
      showToast(done ? '上下文已压缩，历史已折叠' : '压缩失败：请检查 API Key 或网络后重试')
      if (done) {
        setOpen(false)
      }
    } finally {
      setBusy(false)
    }
  }

  const handleRestore = () => {
    if (restoreContext(session.id)) {
      showToast('已展开完整的对话历史')
      setOpen(false)
    } else {
      showToast('展开失败，请稍后重试')
    }
  }

  const handleExport = async () => {
    setBusy(true)
    try {
      const result = await exportSessionText(session)
      if (!result.ok) {
        showToast('导出失败，请稍后重试')
        return
      }
      showToast(result.native ? `已保存到 ${result.location ?? '下载目录'}` : '已开始下载 TXT')
      setOpen(false)
    } catch {
      showToast('导出失败，请稍后重试')
    } finally {
      setBusy(false)
    }
  }

  const handleBackground = async (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    event.target.value = ''
    if (!file) {
      return
    }
    setBusy(true)
    try {
      const dataUrl = await compressImage(file)
      if (setSessionBackground(session.id, dataUrl)) {
        showToast('已更换对话背景')
        setOpen(false)
      } else {
        showToast('设置失败，请稍后重试')
      }
    } catch {
      showToast('这张图片处理失败，换一张试试')
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className={styles.wrap} ref={rootRef}>
      <button
        type="button"
        className={styles.ring}
        aria-label="会话面板"
        aria-expanded={open}
        onClick={() => setOpen((value) => !value)}
      >
        <svg className={styles.svg} viewBox="0 0 40 40" aria-hidden="true">
          <circle className={styles.track} cx="20" cy="20" r={RADIUS} />
          <circle
            className={styles.progress}
            cx="20"
            cy="20"
            r={RADIUS}
            style={{
              strokeDasharray: `${dash} ${CIRCUMFERENCE}`,
              stroke: danger ? 'var(--dsw-alias-state-error-primary, #e5484d)' : undefined,
            }}
          />
        </svg>
        <span className={styles.label}>{Math.round(percent)}%</span>
      </button>
      {open ? (
        <div className={styles.panel} role="dialog" aria-label="会话面板">
          <div className={styles.row}>
            <span className={styles.title}>上下文用量</span>
            <span className={styles.value}>{Math.round(percent)}%</span>
          </div>
          <div className={styles.bar}>
            <div
              className={styles.barFill}
              style={{
                width: `${percent}%`,
                background: danger ? 'var(--dsw-alias-state-error-primary, #e5484d)' : undefined,
              }}
            />
          </div>
          <div className={styles.line}>
            <span>已用（估算）</span>
            <b>{formatFull(usage.used)}</b>
          </div>
          <div className={styles.line}>
            <span>剩余</span>
            <b>{formatFull(usage.remaining)}</b>
          </div>
          <div className={styles.line}>
            <span>窗口上限</span>
            <b>{formatFull(usage.limit)}</b>
          </div>
          <div className={styles.line}>
            <span>计入上下文</span>
            <b>
              {usage.messages} 条 / {usage.rounds} 轮
            </b>
          </div>
          {usage.actual === undefined ? null : (
            <div className={styles.line}>
              <span>上次请求实耗</span>
              <b>{formatFull(usage.actual)}</b>
            </div>
          )}
          {usage.compressed > 0 ? (
            <div className={styles.hint}>
              已有 {usage.compressed} 条历史被压缩，不再进入后续对话。
            </div>
          ) : null}

          <div className={styles.divider} />
          <div style={rowStyle}>
            <div className={styles.model} title={`${profile.model}（${profile.baseUrl}）`}>
              模型：{profile.name} · {profile.model}
            </div>
            <Button size="s" variant="outlined" onClick={openModelDialog}>
              切换
            </Button>
          </div>

          <div className={styles.actions}>
            <Button size="s" variant="outlined" disabled={busy} onClick={handleCompress}>
              {busy ? '处理中…' : '压缩上下文'}
            </Button>
            {usage.compressed > 0 ? (
              <Button size="s" variant="outlined" disabled={busy} onClick={handleRestore}>
                展开历史
              </Button>
            ) : null}
          </div>
          <div className={styles.actions}>
            <Button size="s" variant="outlined" disabled={busy} onClick={handleExport}>
              导出全部 TXT
            </Button>
          </div>
          <div className={styles.actions}>
            <Button size="s" variant="outlined" disabled={busy} onClick={() => fileRef.current?.click()}>
              换背景图
            </Button>
            {session.background ? (
              <Button
                size="s"
                variant="outlined"
                disabled={busy}
                onClick={() => {
                  setSessionBackground(session.id, null)
                  showToast('已恢复默认背景')
                  setOpen(false)
                }}
              >
                移除背景
              </Button>
            ) : null}
          </div>
          <div className={styles.actions}>
            <Button
              size="s"
              variant="outlined"
              onClick={() => {
                setOpen(false)
                startSelection()
              }}
            >
              选择消息（导出/删除）
            </Button>
          </div>
          <input
            ref={fileRef}
            type="file"
            accept="image/*"
            style={{ display: 'none' }}
            onChange={handleBackground}
          />
        </div>
      ) : null}
    </div>
  )
}
