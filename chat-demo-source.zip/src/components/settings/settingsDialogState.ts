import { create } from 'zustand'
import { getActiveProfile, getProfileApiKey } from '../../services/models.js'
import { useSettings } from '../../services/settings.js'

/** 设置弹窗的分组：通用设置 / 数据管理 */
export type SettingsSection = 'general' | 'data'

/** 设置弹窗：侧边栏底部、没有 API Key 时的操作与 401 提示都可以打开；section 为打开时选中的分组 */
export const useSettingsDialog = create(() => ({
  open: false,
  section: 'general' as SettingsSection,
}))

export const openSettings = (section: SettingsSection) =>
  useSettingsDialog.setState({ open: true, section })

export const closeSettings = () => useSettingsDialog.setState({ open: false })

/** 没有 API Key 时打开设置并选中 API Key 所在的「数据管理」，返回是否已有 Key */
export const ensureApiKey = () => {
  if (useSettings.getState().apiKey) {
    return true
  }
  // 当前选的是自带 Key 的第三方模型时，不强制要求 DeepSeek 的 Key
  const profile = getActiveProfile()
  if (profile.protocol !== 'deepseek' && getProfileApiKey(profile)) {
    return true
  }
  openSettings('data')
  return false
}
