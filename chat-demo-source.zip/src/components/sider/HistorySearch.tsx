import clsx from 'clsx'
import { useEffect, useState } from 'react'
import type { ReactNode } from 'react'
import { revealMessage, selectSession } from '../../services/chat/store.js'
import { searchHistory, type HistoryHit } from '../../services/chat/searchHistory.js'
import { useFocusMessage } from '../messages/focusMessage.js'
import { closeMobileSider } from './mobileSiderState.js'
import styles from './HistorySearch.module.css'

/** 关键词高亮 */
const Highlight = ({ text, keyword }: { text: string; keyword: string }) => {
  const target = keyword.trim().toLowerCase()
  if (!target) {
    return <>{text}</>
  }
  const parts: ReactNode[] = []
  let rest = text
  let index = rest.toLowerCase().indexOf(target)
  let key = 0
  while (index !== -1 && key < 20) {
    if (index > 0) {
      parts.push(rest.slice(0, index))
    }
    parts.push(
      <mark key={key} className={styles.mark}>
        {rest.slice(index, index + target.length)}
      </mark>
    )
    key += 1
    rest = rest.slice(index + target.length)
    index = rest.toLowerCase().indexOf(target)
  }
  if (rest) {
    parts.push(rest)
  }
  return <>{parts}</>
}

/** 侧边栏的历史搜索框：输入关键词后列出所有会话里的命中消息 */
export const HistorySearch = ({
  query,
  onQueryChange,
}: {
  query: string
  onQueryChange: (value: string) => void
}) => {
  const [hits, setHits] = useState<HistoryHit[]>([])
  const [loading, setLoading] = useState(false)
  const focus = useFocusMessage((state) => state.focus)
  const expanded = query.trim().length > 0

  useEffect(() => {
    if (!expanded) {
      setHits([])
      setLoading(false)
      return
    }
    let cancelled = false
    setLoading(true)
    const timer = window.setTimeout(() => {
      void searchHistory(query)
        .then((found) => {
          if (!cancelled) {
            setHits(found)
            setLoading(false)
          }
        })
        .catch(() => {
          if (!cancelled) {
            setHits([])
            setLoading(false)
          }
        })
    }, 250)
    return () => {
      cancelled = true
      window.clearTimeout(timer)
    }
  }, [query, expanded])

  const open = async (hit: HistoryHit) => {
    selectSession(hit.sessionId)
    // 命中历史版本时先把那条分支切到可见路径上
    await revealMessage(hit.sessionId, hit.messageId)
    focus(hit.messageId)
    closeMobileSider()
  }

  return (
    <div className={clsx(styles.root, expanded && styles.expanded)}>
      <div className={styles.box}>
        <span className={styles.icon} aria-hidden="true">
          ⌕
        </span>
        <input
          className={styles.input}
          value={query}
          placeholder="搜索全部对话记录"
          onChange={(event) => onQueryChange(event.target.value)}
        />
        {query ? (
          <button
            type="button"
            className={styles.clear}
            aria-label="清空搜索"
            onClick={() => onQueryChange('')}
          >
            ×
          </button>
        ) : null}
      </div>

      {expanded ? (
        <div className={styles.results}>
          {loading ? <div className={styles.empty}>搜索中…</div> : null}
          {!loading && hits.length === 0 ? (
            <div className={styles.empty}>没有找到「{query.trim()}」</div>
          ) : null}
          {hits.map((hit) => (
            <button
              key={`${hit.sessionId}-${hit.messageId}`}
              type="button"
              className={styles.hit}
              onClick={() => void open(hit)}
            >
              <div className={styles.hitTop}>
                <span className={styles.hitTitle}>{hit.title}</span>
                <span className={styles.hitMeta}>
                  {hit.role === 'user' ? '你' : 'AI'}
                  {hit.hidden ? ' · 历史版本' : ''}
                </span>
              </div>
              <div className={styles.hitSnippet}>
                <Highlight text={hit.snippet} keyword={query} />
              </div>
            </button>
          ))}
        </div>
      ) : null}
    </div>
  )
}
